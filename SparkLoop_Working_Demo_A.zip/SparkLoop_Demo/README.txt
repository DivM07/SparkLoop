SPARKLOOP DEMO
================
Open index.html in a browser.

Presentation flow (about 90 seconds):
1. Dashboard → show 3 skipped lessons, error streak, slower response.
2. Click "Let SparkLoop step in" → AI classifies cause as STUCK and generates a <=25 word nudge.
3. Complete the 5-minute challenge → streak changes 7 → 8 and skipped lessons drop 3 → 2.
4. Click "Simulate offline", then complete/retry → action is saved locally / "sync later".
5. Click "View prompt engineering" and "View validation" for the hackathon evidence slides.

This is a front-end working prototype. It intentionally simulates the model output so the demo is deterministic and does not require an API key.
The deck's architecture is represented in the UI: React/PWA-style client behavior, AI layer concept, SQLite/local-cache concept, offline-first flow.
