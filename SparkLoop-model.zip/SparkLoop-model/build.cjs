const esbuild = require('esbuild');
esbuild.buildSync({entryPoints:['src/app.jsx'],bundle:true,minify:true,outfile:'dist/app.js',loader:{'.js':'jsx'},define:{'process.env.NODE_ENV':'"production"'}});
