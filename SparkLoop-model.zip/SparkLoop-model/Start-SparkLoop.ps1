$ErrorActionPreference = 'Stop'
$modelRoot = $PSScriptRoot
$taskRoot = Split-Path (Split-Path $modelRoot -Parent) -Parent
$bundledPython = 'C:\Users\AdityaSharma\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
$dependencyPath = Join-Path $taskRoot 'work\python-deps'
if (Test-Path -LiteralPath $bundledPython) { $pythonExe=$bundledPython } else { $pythonExe=(Get-Command python).Source }
if (Test-Path -LiteralPath $dependencyPath) { $env:PYTHONPATH=$dependencyPath }
$arguments=@('-m','uvicorn','backend.app:app','--host','127.0.0.1','--port','8765')
Start-Process -FilePath $pythonExe -ArgumentList $arguments -WorkingDirectory $modelRoot -WindowStyle Hidden
Start-Sleep -Seconds 2
Start-Process 'http://127.0.0.1:8765'
