@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-SparkLoop.ps1"
