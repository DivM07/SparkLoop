# SparkLoop working model

Start the app by double-clicking **Start-SparkLoop.cmd** on this computer. The presentation URL is **http://127.0.0.1:8765**. Open it once while online to cache the offline app.

## 90-second presentation flow

1. Click **Reset demo**. Riya has skipped three lessons and says the exercises feel repetitive.
2. Click **Find my next step**. Show the cause-specific nudge and **How the coach decided**: structured JSON, signal evidence, and a nudge no longer than 25 words.
3. Toggle **Online** to **Offline mode**. Start the five-minute challenge. Answers: **8**, **₹160**, **18**.
4. Finish practice. Show the completion, saved progress, and earned streak. Multiple completions on one day never add extra streak days.
5. Toggle back online. Pending events sync to the local **FastAPI / SQLite** server. Open **My progress** to show the activity log.
6. Pick **Slow, but correct**. The coach reports **No cause established** and offers optional review. This demonstrates that careful work is not treated as disengagement.

## Included

- React application, four built-in lessons, question feedback and worked examples.
- Bored / stuck / alone / insufficient-evidence classification and short nudges.
- Five-minute timed challenges. The timer can pause. Practice can continue after time ends.
- Offline PWA cache, device progress, queued events, idempotent SQLite sync.
- Six labelled simulated scenarios, reset, progress export, and transparent JSON inspection.
- Server-side Claude integration with role prompt, few-shot examples, JSON schema, and validation.

## Claude setup

The live Claude request did not produce a verified successful response. The working demo uses **deterministic offline rules**, clearly labelled. To enable live Claude, set a valid `ANTHROPIC_API_KEY` in the server environment and restart the server. The optional model setting defaults to `claude-sonnet-4-6`. `.env.example` is a reference, not an automatically loaded key file. Never put your key in the browser or source code.

The shareable hosted browser version uses device storage and offline rules. Server sync and Claude run in the local app. Teacher dashboard and peer matching are future features in the deck and are not implemented.

## Run on another computer

Install Python 3.10 or newer. Run `python -m pip install -r requirements.txt`, then `python -m uvicorn backend.app:app --host 127.0.0.1 --port 8765` from this folder. The prebuilt frontend is included, so Node is not needed to run it. For frontend edits, `npm install` and `npm run build`.

## Limits

Student signals and the initial two-day streak are simulated demo data. Completing all three questions correctly earns a real local completion for today. This is a single-student presentation model without production authentication. Device progress stays in this browser; synced events are stored in SQLite. The deck’s historical 8/10 claim is not a measured result for this implementation.

API references: [Anthropic Messages API](https://platform.claude.com/docs/en/api/messages/create), [structured outputs](https://platform.claude.com/docs/en/build-with-claude/structured-outputs).
